#include "Tree.h"

template <class T> 
class SearchTree : public Tree<T>
{
public:
	// protocol for search trees
	void Add(T value);
	int  Includes(T value) const {return Includes(root,value);}
	bool Remove(T value);
private:
	void Add(Node<T> * current, T val);
	int  Includes(Node<T> * current, T val) const;
	// method used internally to delete top Node
	bool Remove(Node<T> *, Node<T> * parent, T val);
};

template <class T> 
void SearchTree<T>::Add(T val)
{
	// Add value to binary search tree 
	if (!root)
	{
		root = new Node<T>(val);
		return;
	}
	Add(root,val);
}
template <class T> 
void SearchTree<T>::Add(Node<T> * current,T val)
{
	if (current->value < val)
		// Add to right subtree
		if (!current->right)
		{
			current->right=new Node<T>(val);
			return;
		}
		else Add(current->right,val);
	else
		// Add to left subtree
		if (!current->left)
		{
			current->left=new Node<T>(val);
			return;
		}
		else Add(current->left,val);
}

template <class T> 
int SearchTree<T>::Includes(Node<T> * current,T val) const
{
	// see if argument value occurs in tree
	if(!current)
		return 0;	// not found, we arrive a leaf
	if (current->value == val)
		return 1;
	if (current->value < val)
		return Includes(current->right,val);
	else
		return Includes(current->left,val);
}

template <class T> 
bool SearchTree<T>::Remove(T val)
{
	return Remove (root, NULL, val);
}

template <class T> 
bool SearchTree<T>::Remove(Node<T> * current, Node<T> * parent, T val)
{
	//1. we arrive a leaf, node to remove was not founded
	if(!current)
		return false;	
	
	//2. we found the node to remove, lets delete it by the correct case:
		//2.1 it is a leaf
		//2.2 it is internal node with only one child
		//2.3 it is internal node with two childrens

	if (current->value == val)
	{
		//2.1 current node is a leaf, simply delete it
		if (!current->left && !current->right )
		{
			
			//before delete current, NULL the pointer to it on its parent
			parent->left == current ? parent->left = NULL : parent->right = NULL;

			delete current;
			current = NULL;
			
			return true;
		}

		//2.2 it is internal node with only one child, 
		//		switch this child with current node and delete it
		if (current->left && !current->right )
		{//only left child exists
			
		}


		//2.3 it is internal node with two childrens


	}

	//3. value of the node is bigger then current, lets search down right
	if (current->value < val)
		Remove (current->right, current, val);
	else
	//4. value of the node is smaller then current, lets search down left
		Remove(current->left, current, val);
}


