#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "searchTree.h"
using namespace std;

void main()
{
	
	SearchTree<int> T;
	srand((unsigned)time(NULL));
	for (int i=0;i<10;i++)
		T.Add(rand()%100);
	cout<<"InOrder:\t";		T.InOrder();	cout<<endl;
	cout<<"PreOrder:\t";	T.PreOrder();	cout<<endl;
	cout<<"PostOrder:\t";	T.PostOrder();	cout<<endl;

	int val;
	do
	{
		cout<< "enter number for searching in tree (0 for stop):";
		cin>>val;
		
		if (val)
		{
			if (T.Includes(val))
				cout<<"yes"<<endl;
			else 
				cout<<"no"<<endl;
		}
	}
	while (val != 0);
	

	SearchTree<int> T2;
	
	T2.Add(10);
	T2.Add(14);
	T2.Add(12);
	//T2.Add(2);
	//T2.Add(8);
	

	T2.InOrder();

	bool b = T2.AllBiggerThanRoot();

	system("pause");

}


