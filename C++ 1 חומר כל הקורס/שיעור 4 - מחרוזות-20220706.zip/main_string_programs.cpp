#include <iostream>
#include <string>
using namespace std;


void main()
{
	
// error in run time
	/*string word = "today";
    word.insert(7,"tomorrow");*/


// print it wasining 
string present= "it is raining"; 
string past = present;
past.replace(3,5,"was");

cout<< past<<endl;

// no fitting function
/*string word = "happy.";
word.replace(5,1,3,"!");*/

//4
string americanFormat = "March 18, 2012";
string universalFormat;

int space = americanFormat.find(" ");

string month = americanFormat.substr(0,space);

cout<<"month:"<< month <<endl; 

int psik = americanFormat.find(",");


string day = americanFormat.substr(space,psik-space);
cout<<"day:"<< day <<endl; 

string year = americanFormat.substr(psik+1, americanFormat.length()-(psik+1));
cout<<"year:"<< year <<endl;


//check input
bool check = true;

if( atoi(year.c_str()) < 1970  ||atoi(year.c_str()) >2012) 
	check = false;


if(check)
	universalFormat = day + " " + month + year;

cout<<"universalFormat:"<< universalFormat <<endl;



	system("pause");

}