#pragma once

#include <iostream>

using namespace std;


class Vector
{

private:

	int* vec;

	int size;

	static int counter;

public:

	Vector(int _size = 10);

	Vector(const Vector&);

	~Vector();

	void setItem(int, int);

	int getItem(int);

	static int getCounter();

};

// CTOR

Vector::Vector(int _size)

{

	size = _size;

	cout << "Constructing vector. Size = " << size << endl;

	vec = new int[size];

	counter++;

	cout << "We have " << counter << " Vector objects.\n\n";

}




// Copy CTOR

Vector::Vector(const Vector& other)

{

	size = other.size;

	cout << "Copy Constructing vector. Size = " << size << endl;

	vec = new int[size];

	for (int i = 0; i < size; i++)

		vec[i] = other.vec[i];

	counter++;

	cout << "We have " << counter << " Vector objects.\n\n";

}




// DTOR

Vector::~Vector()

{

	cout << "Destructing vector. Size = " << size << endl;

	delete[] vec;

	counter--;

	cout << "We have " << counter << " Vector objects.\n\n";

}



void Vector::setItem(int index, int value)

{

	if (index >= 0 && index <= size)

		vec[index] = value;

	else

		//cout << "Index " << index << " is out of range!";
		throw index;

}




int Vector::getItem(int index)

{

	if (index >= 0 && index <= size)

		return vec[index];

	else

	{
		throw index;
		//cout << "Index " << index << " is out of range!";
		//return 0;
	}
	
	return 0;

}




// Static members

int Vector::counter = 0;

int Vector::getCounter()
{
	return counter;
}


/*main*/

Vector f2(Vector v5)
{
	v5.setItem(0, -10);
	return v5;
}

void f1()
{

	cout << "We have " << Vector::getCounter() << " Vector objects.\n";

	Vector v1, v2(20), v3(v2); //counter = 3

	Vector v4(f2(v1)); //counter=4, coutnter =5, c=4,c=5

	cout << "v4[0] = " << v4.getItem(0) << endl; //-10

	cout << "We have " << Vector::getCounter() << " Vector objects.\n";
	
	cout<<"END"<<endl;
	

} //c=4



int main()
{
	//system("color 9f");

	try
	{
		f1();
	}
	catch (int index)
	{
		cout << "Index " << index << " is out of range!";
	}
	catch(...)
	{
		cout << "general error";
	}

	system("pause");
}